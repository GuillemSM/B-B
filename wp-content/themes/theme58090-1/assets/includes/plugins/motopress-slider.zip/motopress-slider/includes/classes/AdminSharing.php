<?php

class MPSLAdminSharing {
	public static $presets = array();
	public static $defaultPresets = array();
	public static $privatePresets = array();
	public static $gFontsUrl = '';
}