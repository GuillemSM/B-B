<?php if (!defined('ABSPATH')) exit; ?>
<div class="mpsl-slider-preview">
	<div class="mpsl-resolution-buttons-wrapper hidden">
		<div class="container">
			<div class="item desktop active"></div>
			<div class="item tablet"></div>
			<div class="item mobile"></div>
		</div>
	</div>
	<iframe src="" frameborder="0" id="mpsl-slider-preview" name="mpsl-slider-preview"></iframe>
	<div class="mpsl-preloader" style="display: none;"></div>
</div>