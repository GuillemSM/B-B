<?php

class MPSLSharing {
	public static $isScriptsStylesEnqueued = false;
	public static $isPreviewPage = false;
	public static $isMPCEEditor = false;
}