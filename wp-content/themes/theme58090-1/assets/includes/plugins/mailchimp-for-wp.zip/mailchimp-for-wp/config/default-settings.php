<?php
return array(
	'api_key' => '',
	'allow_usage_tracking' => 0
);